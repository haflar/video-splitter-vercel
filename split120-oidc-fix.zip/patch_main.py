from pathlib import Path

p = Path("src/main.js")
s = p.read_text()

old_import = "import { upload } from '@vercel/blob/client';"
new_import = "import { uploadPresigned } from '@vercel/blob/client';"

if old_import not in s and new_import not in s:
    raise SystemExit("Import @vercel/blob/client introuvable dans src/main.js")

s = s.replace(old_import, new_import)

old_call = "const source = await upload(`uploads/${Date.now()}-${safeName}`, selectedFile, {"
new_call = "const source = await uploadPresigned(`uploads/${Date.now()}-${safeName}`, selectedFile, {"

if old_call not in s and new_call not in s:
    raise SystemExit("Appel upload() introuvable dans src/main.js")

s = s.replace(old_call, new_call)
p.write_text(s)
print("src/main.js corrigé pour uploadPresigned()")
